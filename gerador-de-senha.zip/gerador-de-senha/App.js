import React, { useState } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';

const App = () => {
  const [normalCount, setNormalCount] = useState(0);
  const [prioritaryCount, setPrioritaryCount] = useState(0);
  const [highPriorityCount, setHighPriorityCount] = useState(0);
  const [generatedPassword, setGeneratedPassword] = useState('');

  const generateNormalPassword = () => {
    const newCount = normalCount + 1;
    const password = `N${String(newCount).padStart(2, '0')}`;
    setGeneratedPassword(password);
    setNormalCount(newCount);
  };

  const generatePrioritaryPassword = () => {
    const newCount = prioritaryCount + 1;
    const password = `P${String(newCount).padStart(2, '0')}`;
    setGeneratedPassword(password);
    setPrioritaryCount(newCount);
  };

  const generateHighPriorityPassword = () => {
    const newCount = highPriorityCount + 1;
    const password = `AP${String(newCount).padStart(3, '0')}`; // Modificado para ter 3 dígitos
    setGeneratedPassword(password);
    setHighPriorityCount(newCount);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerador de Senhas de Atendimento</Text>
      <View style={styles.buttonContainer}>
        <View style={styles.buttonWrapper}>
          <Button title="Senha Normal" onPress={generateNormalPassword} />
        </View>
        <View style={styles.buttonWrapper}>
          <Button title="Senha Prioritária" onPress={generatePrioritaryPassword} />
        </View>
        <View style={styles.buttonWrapper}>
          <Button title="Senha Alta Prioridade" onPress={generateHighPriorityPassword} />
        </View>
      </View>
      <Text style={styles.passwordDisplay}>Senha Gerada: {generatedPassword}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
  },
  buttonWrapper: {
    marginVertical: 10,
    width: '80%',
  },
  passwordDisplay: {
    fontSize: 20,
    marginTop: 20,
  },
});

export default App;