import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handlePress = (value) => {
    setInput(input + value);
  };

  const calculateResult = () => {
    try {
      setResult(eval(input).toString());
    } catch (error) {
      setResult('Erro');
    }
  };

  const clearInput = () => {
    setInput('');
    setResult('');
  };

  return (
    <View style={styles.container}>
      <View style={styles.screen}>
        <Text style={styles.inputText}>{input}</Text>
        <Text style={styles.resultText}>{result}</Text>
      </View>
      <View style={styles.buttonContainer}>
        <View style={styles.row}>
          <Button title="1" onPress={handlePress} />
          <Button title="2" onPress={handlePress} />
          <Button title="3" onPress={handlePress} />
          <Button title="+" onPress={handlePress} />
        </View>
        <View style={styles.row}>
          <Button title="4" onPress={handlePress} />
          <Button title="5" onPress={handlePress} />
          <Button title="6" onPress={handlePress} />
          <Button title="-" onPress={handlePress} />
        </View>
        <View style={styles.row}>
          <Button title="7" onPress={handlePress} />
          <Button title="8" onPress={handlePress} />
          <Button title="9" onPress={handlePress} />
          <Button title="*" onPress={handlePress} />
        </View>
        <View style={styles.row}>
          <Button title="C" onPress={clearInput} style={styles.clearButton} />
          <Button title="0" onPress={handlePress} />
          <Button title="=" onPress={calculateResult} style={styles.equalsButton} />
          <Button title="/" onPress={handlePress} />
        </View>
      </View>
    </View>
  );
}

const Button = ({ title, onPress, style }) => (
  <TouchableOpacity style={[styles.button, style]} onPress={() => onPress(title)}>
    <Text style={styles.buttonText}>{title}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  screen: {
    width: '80%',
    padding: 20,
    backgroundColor: '#222',
    borderRadius: 10,
    marginBottom: 20,
    alignItems: 'flex-end',
  },
  inputText: {
    color: '#fff',
    fontSize: 36,
    fontWeight: 'bold',
  },
  resultText: {
    color: '#fff',
    fontSize: 48,
    fontWeight: 'bold',
  },
  buttonContainer: {
    width: '80%',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  button: {
    width: '22%',
    height: 70,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
  },
  clearButton: {
    backgroundColor: '#FF5722',
  },
  equalsButton: {
    backgroundColor: '#4CAF50',
  },
  buttonText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
});
